package StudentManagement;

import java.sql.*;
import javax.swing.*;


public class NewUser extends NewAdmin {

    
    @Override
    protected void AddButtonActionPerformed() {
        
        if(txtUser.getText().length() == 0){
            JOptionPane.showMessageDialog(this, "Username cannot be empty");
        }
        
        else if(txtPass.getText().length() == 0){
            JOptionPane.showMessageDialog(this, "Password cannot be empty");
        }
        
        else if(txtPass.getText().equals(txtConfirm.getText()) == false){
            JOptionPane.showMessageDialog(this, "Password and Confirm Password do not match");
        }
        
        else{
            try {
                
                String username = txtUser.getText();
                String confirmpass = txtConfirm.getText();
                
                
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
                pst = con.prepareStatement("insert into user(username,password)values(?,?)");
                
                pst.setString(1, username);
                pst.setString(2, confirmpass);

                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "User added...");
                
                txtUser.setText("");
                txtPass.setText("");
                txtConfirm.setText("");

                
                txtUser.requestFocus();
                
                
            } catch (ClassNotFoundException | SQLException ex) {
                System.out.println(ex);
            }
        }
    }    
}
