package StudentManagement;

public interface User {
    public static void view_list_of_batches(){
        ListBatches lb = new ListBatches();
        lb.setVisible(true);
    }
    
    public static void view_list_of_courses(){
        ListCourses lc = new ListCourses();
        lc.setVisible(true);
    }
    
    public static void logout(javax.swing.JFrame jf){
        Login l2 = new Login();
        jf.hide();
        l2.setVisible(true);
    }
}
