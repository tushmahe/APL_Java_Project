
package StudentManagement;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;
import java.awt.event.*;


public class Registration extends JFrame {

   
    public Registration() {
        initComponents();
        courses();
        batch();
    }
    
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    PreparedStatement pst2;
    ResultSet rs;
    
    
    
    public void courses(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            
            pst1 = con.prepareStatement("select * from course");
            rs = pst1.executeQuery();
            
            txtcourse.removeAllItems();
            
            while(rs.next())
            {
                txtcourse.addItem(rs.getString(2));
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex);
        }
    }
    
    public void batch(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            
            pst2 = con.prepareStatement("select * from batch");
            rs = pst2.executeQuery();
            
            txtbatch.removeAllItems();
            
            while(rs.next())
            {
                txtbatch.addItem(rs.getString(2));
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @SuppressWarnings("unchecked")
                           
    private void initComponents() {

        jPanel1 = new JPanel();
        jPanel2 = new JPanel();
        Registration = new JLabel();
        FirstName = new JLabel();
        LastName = new JLabel();
        UserName = new JLabel();
        Gender = new JLabel();
        Course = new JLabel();
        Batch = new JLabel();
        PhoneNo = new JLabel();
        Address = new JLabel();
        txtfirst = new JTextField();
        txtlast = new JTextField();
        txtusername = new JTextField();
        jRadioButton1 = new JRadioButton();
        jRadioButton2 = new JRadioButton();
        txtcourse = new JComboBox<>();
        txtbatch = new JComboBox<>();
        txttel = new JTextField();
        jScrollPane1 = new JScrollPane();
        txtaddress = new JTextArea();
        SaveButton = new JButton();
        CancelButton = new JButton();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(220, 143, 143));

        Registration.setFont(new java.awt.Font("Calibri", 1, 36));
        Registration.setForeground(new java.awt.Color(255, 255, 255));
        Registration.setText("REGISTRATION");

        GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(159, 159, 159)
                .addComponent(Registration)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(Registration)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        FirstName.setText("First Name");

        LastName.setText("Last Name");

        UserName.setText("Username");

        Gender.setText("Gender");

        Course.setText("Course");

        Batch.setText("Batch");

        PhoneNo.setText("Phone No");

        Address.setText("Address");

        jRadioButton1.setText("Male");

        jRadioButton2.setText("Female");

        txtcourse.setModel(new DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtbatch.setModel(new DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtaddress.setColumns(20);
        txtaddress.setRows(5);
        jScrollPane1.setViewportView(txtaddress);

        SaveButton.setText("Save");
        SaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                SaveButtonActionPerformed();
            }
        });

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                CancelButtonActionPerformed();
            }
        });

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(LastName)
                    .addComponent(FirstName)
                    .addComponent(UserName, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
                    .addComponent(Gender, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
                    .addComponent(Course, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
                    .addComponent(Batch, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
                    .addComponent(PhoneNo)
                    .addComponent(Address, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jRadioButton1, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButton2, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtfirst)
                    .addComponent(txtlast)
                    .addComponent(txtusername)
                    .addComponent(txtcourse, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtbatch, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txttel)
                    .addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(134, Short.MAX_VALUE)
                .addComponent(SaveButton, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
                .addGap(126, 126, 126)
                .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 85, GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(FirstName, GroupLayout.PREFERRED_SIZE, 14, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtfirst, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(LastName)
                    .addComponent(txtlast, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(UserName)
                    .addComponent(txtusername, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButton1)
                    .addComponent(Gender)
                    .addComponent(jRadioButton2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(Course)
                    .addComponent(txtcourse, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(Batch)
                    .addComponent(txtbatch, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(PhoneNo)
                    .addComponent(txttel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(Address)
                    .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(SaveButton, GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(CancelButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }                        

    private void CancelButtonActionPerformed() {                                         
        this.hide();
    }                                        

    private void SaveButtonActionPerformed() {                                         
        try {
            
            String firstname = txtfirst.getText();
            String lastname = txtlast.getText();
            String username = txtusername.getText();
            String Gender;
            
            if(jRadioButton1.isSelected()){
            
                Gender = "Male";
            }
            else
            {
                Gender = "Female";
            }
            
            String course = txtcourse.getSelectedItem().toString();
            String batch = txtbatch.getSelectedItem().toString();
            
            String telephone = txttel.getText();
            
            String address = txtaddress.getText();
            

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            
            
            pst = con.prepareStatement("insert into registration(firstname, lastname, username, gender, course, batch, telephone, address)values(?,?,?,?,?,?,?,?)");
        
            pst.setString(1, firstname);
            pst.setString(2, lastname);
            pst.setString(3, username);
            pst.setString(4, Gender);
            pst.setString(5, course);
            pst.setString(6, batch);
            pst.setString(7, telephone);
            pst.setString(8, address);
            
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Successfully Registered...!");
            
            txtfirst.setText("");
            txtlast.setText("");
            txtusername.setText("");
            txtcourse.setSelectedIndex(-1);
            txtbatch.setSelectedIndex(-1);
            txttel.setText("");
            txtaddress.setText("");
            txtfirst.requestFocus();
            
        
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                        

                         
    private JButton SaveButton;
    private JButton CancelButton;
    private JLabel Registration;
    private JLabel FirstName;
    private JLabel LastName;
    private JLabel UserName;
    private JLabel Gender;
    private JLabel Course;
    private JLabel Batch;
    private JLabel PhoneNo;
    private JLabel Address;
    private JPanel jPanel1;
    private JPanel jPanel2;
    private JRadioButton jRadioButton1;
    private JRadioButton jRadioButton2;
    private JScrollPane jScrollPane1;
    private JTextArea txtaddress;
    private JComboBox<String> txtbatch;
    private JComboBox<String> txtcourse;
    private JTextField txtfirst;
    private JTextField txtlast;
    private JTextField txttel;
    private JTextField txtusername;
                      
}

