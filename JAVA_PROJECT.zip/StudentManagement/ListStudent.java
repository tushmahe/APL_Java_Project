package StudentManagement;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;
import javax.swing.table.*;


public class ListStudent extends JFrame {

    
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    PreparedStatement pst2;
    ResultSet rs;
    
    public ListStudent() {
        initComponents();
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            
            pst2 = con.prepareStatement("select * from registration");
            rs = pst2.executeQuery();
            
            Stable.removeAll();
            
            while(rs.next())
            {
                DefaultTableModel model = (DefaultTableModel) Stable.getModel();
                model.addRow(new Object[]{Integer.toString(rs.getInt(1)), rs.getString(2) + " " + rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)});
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex);
        }
    }

    
    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        jScrollPane1 = new JScrollPane();
        Stable = new JTable();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        Stable.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Name", "Username", "Gender", "Course", "Batch", "Phone Number", "Address"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            @Override
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
            
            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Stable.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
        Stable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(Stable);

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 764, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }                        

    private JTable Stable;
    private JScrollPane jScrollPane1;
    
}

