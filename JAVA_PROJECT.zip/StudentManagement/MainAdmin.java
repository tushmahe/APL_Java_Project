package StudentManagement;

import java.awt.event.*;
import javax.swing.*;

public class MainAdmin extends JFrame implements User{
   
    public MainAdmin() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
                               
    private void initComponents() {

        AddCourseButton = new JButton();
        AddBatchButton = new JButton();
        AddAdminButton = new JButton();
        ViewBatchesButton = new JButton();
        ViewCoursesButton = new JButton();
        ViewStudentsButton = new JButton();
        jPanel1 = new JPanel();
        WelcomeBack = new JLabel();
        LogOutButton = new JButton();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        AddCourseButton.setText("Add Course");
        AddCourseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                AddCourseButtonActionPerformed();
            }
        });

        AddBatchButton.setText("Add Batch");
        AddBatchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                AddBatchButtonActionPerformed();
            }
        });

        AddAdminButton.setText("Add Admin");
        AddAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                AddAdminButtonActionPerformed();
            }
        });

        ViewBatchesButton.setText("View List of Batches");
        ViewBatchesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                ViewBatchesButtonActionPerformed();
            }
        });

        ViewCoursesButton.setText("View List of Courses");
        ViewCoursesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                ViewCoursesButtonActionPerformed();
            }
        });

        ViewStudentsButton.setText("View Student List");
        ViewStudentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                ViewStudentsButtonActionPerformed();
            }
        });

        jPanel1.setBackground(new java.awt.Color(212, 136, 136));

        WelcomeBack.setFont(new java.awt.Font("Calibri", 1, 36));
        WelcomeBack.setForeground(new java.awt.Color(255, 255, 255));
        WelcomeBack.setText("Welcome Back !");

        LogOutButton.setText("Log Out");
        LogOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                LogOutButtonActionPerformed();
            }
        });

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(WelcomeBack, GroupLayout.PREFERRED_SIZE, 254, GroupLayout.PREFERRED_SIZE)
                        .addGap(164, 164, 164))
                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(LogOutButton, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(LogOutButton)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(WelcomeBack)
                .addGap(42, 42, 42))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(AddBatchButton, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddCourseButton, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddAdminButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(155, 155, 155)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(ViewBatchesButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ViewCoursesButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ViewStudentsButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 110, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(AddBatchButton, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
                    .addComponent(ViewBatchesButton, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(AddCourseButton, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
                    .addComponent(ViewCoursesButton, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(AddAdminButton, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
                    .addComponent(ViewStudentsButton, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );

        pack();
        setLocationRelativeTo(null);
    }                       

    private void AddBatchButtonActionPerformed() {                                         
        
        Batch b = new Batch();
        b.setVisible(true);
    }                                        

    private void AddCourseButtonActionPerformed() {                                         
        Course c = new Course();
        c.setVisible(true);
    }                                        

    private void AddAdminButtonActionPerformed() {                                         
        NewAdmin n = new NewAdmin();
        n.setVisible(true);
    }                                        

    private void ViewBatchesButtonActionPerformed() {                                         
        User.view_list_of_batches();
    }                                        

    private void ViewCoursesButtonActionPerformed() {                                         
        User.view_list_of_courses();
    }                                        

    private void ViewStudentsButtonActionPerformed() {                                         
        ListStudent ls = new ListStudent();
        ls.setVisible(true);
    }                                        

    private void LogOutButtonActionPerformed() {                                         
        User.logout(this);
    }                                        

                     
    private JButton AddCourseButton;
    private JButton AddBatchButton;
    private JButton AddAdminButton;
    private JButton ViewBatchesButton;
    private JButton ViewCoursesButton;
    private JButton ViewStudentsButton;
    private JButton LogOutButton;
    private JLabel WelcomeBack;
    private JPanel jPanel1;
                    
}
