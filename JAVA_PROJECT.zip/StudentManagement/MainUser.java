package StudentManagement;
import java.awt.event.*;
import javax.swing.*;

public class MainUser extends JFrame implements User {
    

    public MainUser() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
                     
    private void initComponents() {

        FillApplicationFormButton = new JButton();
        ViewCoursesButton = new JButton();
        ViewBatchesButton = new JButton();
        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        LogOutButton = new JButton();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        FillApplicationFormButton.setText("Fill Application Form");
        FillApplicationFormButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                FillApplicationFormButtonActionPerformed();
            }
        });

        ViewCoursesButton.setText("View Courses");
        ViewCoursesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                ViewCoursesButtonActionPerformed();
            }
        });

        ViewBatchesButton.setText("View List of Batches");
        ViewBatchesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                ViewBatchesButtonActionPerformed();
            }
        });

        jPanel1.setBackground(new java.awt.Color(203, 130, 130));

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 24));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Welcome to our Admission Portal !");

        LogOutButton.setFont(new java.awt.Font("Tahoma", 0, 8));
        LogOutButton.setText("Log Out");
        
        LogOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                LogOutButtonActionPerformed();
            }
        });

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 362, GroupLayout.PREFERRED_SIZE)
                    .addComponent(LogOutButton, GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(LogOutButton)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(40, 40, 40))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(FillApplicationFormButton, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
                    .addComponent(ViewCoursesButton, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
                    .addComponent(ViewBatchesButton, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ViewBatchesButton, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(ViewCoursesButton, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FillApplicationFormButton, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        pack();
    }                        

    private void FillApplicationFormButtonActionPerformed() {                                         
        Registration r = new Registration();
        r.setVisible(true);
    }                                        

    private void ViewBatchesButtonActionPerformed() {                                         
           User.view_list_of_batches();
    }                                        

    private void ViewCoursesButtonActionPerformed() {                                         
        User.view_list_of_courses();
    }                                        

    private void LogOutButtonActionPerformed() {                                         
        User.logout(this);
    }                                        

                        
    private JButton FillApplicationFormButton;
    private JButton ViewCoursesButton;
    private JButton ViewBatchesButton;
    private JButton LogOutButton;
    private JLabel jLabel1;
    private JPanel jPanel1;
                       
}

