package StudentManagement;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;
import java.awt.event.*;


public class NewAdmin extends JFrame {

    
    public NewAdmin() {
        initComponents();
    }
    
    Connection con;
    PreparedStatement pst;

    
    @SuppressWarnings("unchecked")
    
    protected void initComponents() {

        txtConfirm = new JPasswordField();
        AddButton = new JButton();
        CancelButton = new JButton();
        Username = new JLabel();
        Password = new JLabel();
        ConfirmPassword = new JLabel();
        txtUser = new JTextField();
        txtPass = new JPasswordField();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        AddButton.setText("Add");
        AddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                AddButtonActionPerformed();
            }
        });

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                CancelButtonActionPerformed();
            }
        });

        Username.setText("Username");

        Password.setText("Password");

        ConfirmPassword.setText("Confirm Password");

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                                .addComponent(Username, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Password, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(ConfirmPassword)))
                    .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(AddButton, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(txtPass, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtConfirm, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUser, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(66, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(Username)
                    .addComponent(txtUser, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(ConfirmPassword)
                            .addComponent(txtConfirm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGap(47, 47, 47)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(AddButton, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
                            .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(Password)
                            .addComponent(txtPass, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }

    protected void AddButtonActionPerformed() {
        

        if(txtUser.getText().length() == 0){
            JOptionPane.showMessageDialog(this, "Username cannot be empty");
        }

        else if(txtPass.getText().length() == 0){
            JOptionPane.showMessageDialog(this, "Password cannot be empty");
        }

        else if(txtPass.getText().equals(txtConfirm.getText()) == false){
            JOptionPane.showMessageDialog(this, "Password and Confirm Password do not match");
        }

        else{
            try {

                String username = txtUser.getText();
                String confirmpass = txtConfirm.getText();
                //                String usertype = txtUtype.getSelectedItem().toString();

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
                pst = con.prepareStatement("insert into admin(username,password)values(?,?)");

                pst.setString(1, username);
                pst.setString(2, confirmpass);
                pst.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "Admin added...");

                txtUser.setText("");
                txtPass.setText("");
                txtConfirm.setText("");

                txtUser.requestFocus();

            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(NewUser.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    protected void CancelButtonActionPerformed() {
        dispose();
    }


    protected JButton AddButton;
    protected JButton CancelButton;
    protected JLabel Username;
    protected JLabel Password;
    protected JLabel ConfirmPassword;
    protected JPasswordField txtConfirm;
    protected JPasswordField txtPass;
    protected JTextField txtUser;
    
}
