package StudentManagement;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;
import java.awt.event.*;


public class Course extends JFrame {

    public Course() {
        initComponents();
    }
    
    Connection con;
    PreparedStatement pst;

    
    @SuppressWarnings("unchecked")                         
    private void initComponents() {

        CourseName = new JLabel();
        Duration = new JLabel();
        txtCourse = new JTextField();
        txtDuration = new JTextField();
        AddButton = new JButton();
        CancelButton = new JButton();
        txtOptionn = new JComboBox<>();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        CourseName.setText("Course Name");

        Duration.setText("Duration");

        AddButton.setText("Add");
        AddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                AddButtonActionPerformed();
            }
        });

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                CancelButtonActionPerformed();
            }
        });

        txtOptionn.setModel(new DefaultComboBoxModel<>(new String[] { "Week", "Month", "Year" }));

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(Duration)
                            .addComponent(CourseName))
                        .addGap(54, 54, 54)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtCourse, GroupLayout.PREFERRED_SIZE, 167, GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtDuration, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtOptionn, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(AddButton, GroupLayout.PREFERRED_SIZE, 85, GroupLayout.PREFERRED_SIZE)
                        .addGap(87, 87, 87)
                        .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 84, GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(89, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(CourseName)
                    .addComponent(txtCourse, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(Duration)
                    .addComponent(txtDuration, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtOptionn, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }                        

    private void AddButtonActionPerformed() {                                         
        
        String Course = txtCourse.getText();
        String Duration = txtDuration.getText();
        String DurationOption = txtOptionn.getSelectedItem().toString();
        
        
        try {
            
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            pst = con.prepareStatement("insert into course(coursename, duration, optionn)values(?,?,?)");
                
                pst.setString(1, Course);
                pst.setString(2, Duration);
                pst.setString(3, DurationOption);
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Course added...");
                
                txtCourse.setText("");
                txtDuration.setText("");
                txtOptionn.setSelectedIndex(-1);
                
                
                txtCourse.requestFocus();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Course.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                        

    private void CancelButtonActionPerformed() {
        this.hide();
    }                                        

                       
    private JButton AddButton;
    private JButton CancelButton;
    private JLabel CourseName;
    private JLabel Duration;
    private JTextField txtCourse;
    private JTextField txtDuration;
    private JComboBox<String> txtOptionn;
             
}

