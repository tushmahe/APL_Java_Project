package StudentManagement;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;
import java.awt.event.*;


public class Batch extends JFrame {

    
    public Batch() {
        initComponents();
    }
    
    Connection con;
    PreparedStatement pst;

    
    @SuppressWarnings("unchecked")
                              
    private void initComponents() {

        BatchName = new JLabel();
        Year = new JLabel();
        txtBatch = new JTextField();
        txtYear = new JTextField();
        Add = new JButton();
        CancelButton = new JButton();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        BatchName.setText("Batch Name");

        Year.setText("Year");

        Add.setText("Add");
        Add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                AddActionPerformed();
            }
        });

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                CancelButtonActionPerformed();
            }
        });

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Year, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
                                .addGap(86, 86, 86)
                                .addComponent(txtYear))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(BatchName)
                                .addGap(60, 60, 60)
                                .addComponent(txtBatch, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(Add, GroupLayout.PREFERRED_SIZE, 85, GroupLayout.PREFERRED_SIZE)
                        .addGap(108, 108, 108)
                        .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 84, GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(BatchName)
                    .addComponent(txtBatch, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(Year)
                    .addComponent(txtYear, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(Add, GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                    .addComponent(CancelButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }                        

    private void AddActionPerformed() {                                         
        
        
        String batchname = txtBatch.getText();
        String year = txtYear.getText();
        
        try {
            
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            pst = con.prepareStatement("insert into batch(batchname, year)values(?,?)");
                
                pst.setString(1, batchname);
                pst.setString(2, year);
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Batch created...");
                
                txtBatch.setText("");
                txtYear.setText("");
                
                
                txtBatch.requestFocus();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Batch.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                        

    private void CancelButtonActionPerformed() {                                             
        this.hide();
    }                                        

                   
    private JButton Add;
    private JButton CancelButton;
    private JLabel BatchName;
    private JLabel Year;
    private JTextField txtBatch;
    private JTextField txtYear;
                      
}

