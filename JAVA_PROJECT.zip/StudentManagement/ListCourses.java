package StudentManagement;

import java.sql.*;
import java.util.logging.*;
import javax.swing.table.*;
import javax.swing.*;

public class ListCourses extends JFrame {

    
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    PreparedStatement pst2;
    ResultSet rs;
    
    
    public ListCourses() {
        initComponents();
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            
            pst2 = con.prepareStatement("select * from course");
            rs = pst2.executeQuery();
            
            Ctable.removeAll();
            
            while(rs.next())
            {
                DefaultTableModel model = (DefaultTableModel) Ctable.getModel();
                model.addRow(new Object[]{Integer.toString(rs.getInt(1)), rs.getString(2), Integer.toString(rs.getInt(3)) + " " + rs.getString(4)});
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    
    @SuppressWarnings("unchecked")
    
    
    private void initComponents() {

        jScrollPane1 = new JScrollPane();
        Ctable = new JTable();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        Ctable.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Course Name", "Duration"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };
            
            @Override
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Ctable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(Ctable);
        if (Ctable.getColumnModel().getColumnCount() > 0) {
            Ctable.getColumnModel().getColumn(0).setResizable(false);
            Ctable.getColumnModel().getColumn(1).setResizable(false);
            Ctable.getColumnModel().getColumn(2).setResizable(false);
        }

       GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 375, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 275, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }                       

                       
    private JTable Ctable;
    private JScrollPane jScrollPane1;
                  
}

