package StudentManagement;

import java.sql.*;
import javax.swing.*;
import java.awt.event.*;


public class Login extends JFrame {

    
    public Login() {
        initComponents();
    }
    
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    
    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel1 = new JPanel();
        jPanel2 = new JPanel();
        Login = new JLabel();
        Username = new JLabel();
        Password = new JLabel();
        txtUser = new JTextField();
        txtPass = new JPasswordField();
        NewUserButton = new JButton();
        LoginButton = new JButton();
        CancelButton = new JButton();
        UserType = new JLabel();
        txtUtype = new JComboBox<>();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(210, 137, 137));

        Login.setFont(new java.awt.Font("Calibri", 1, 36));
        Login.setForeground(new java.awt.Color(255, 255, 255));
        Login.setText("LOGIN");

        GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Login)
                .addGap(190, 190, 190))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addComponent(Login)
                .addGap(41, 41, 41))
        );

        Username.setText("Username");

        Password.setText("Password");

        txtUser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                txtUserActionPerformed(evt);
            }
        });

        txtPass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                txtPassActionPerformed(evt);
            }
        });

        NewUserButton.setText("New User");
        NewUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                NewUserButtonActionPerformed(evt);
            }
        });

        LoginButton.setText("Login");
        LoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                LoginButtonActionPerformed(evt);
            }
        });

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        UserType.setText("User Type");

        txtUtype.setModel(new DefaultComboBoxModel<>(new String[] { "User", "Admin" }));
        

        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(Username)
                        .addComponent(Password)
                        .addComponent(UserType))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(NewUserButton, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)))
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(LoginButton, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                        .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                            .addComponent(txtPass, GroupLayout.PREFERRED_SIZE, 194, GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUtype, GroupLayout.PREFERRED_SIZE, 194, GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUser, GroupLayout.PREFERRED_SIZE, 194, GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(Username)
                    .addComponent(txtUser, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(Password)
                    .addComponent(txtPass, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(UserType)
                    .addComponent(txtUtype, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(NewUserButton, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
                    .addComponent(LoginButton, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
                    .addComponent(CancelButton, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }                       

    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {                                         
        try {
            
            if(txtUser.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(this, "Username cannot be empty!");
            }
            
            else if(txtPass.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(this, "Password cannot be empty!");
            }
            
            else{
                
                String username = txtUser.getText();
                String password = txtPass.getText();
                String utype = txtUtype.getSelectedItem().toString();
                
                
                 Class.forName("com.mysql.jdbc.Driver");
                 con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
                   
                 if(utype == "Admin"){
                 pst = con.prepareStatement("select * from admin where username = ? and password = ?");
                 
                 pst.setString(1, username);
                 pst.setString(2, password);
                 
                 rs = pst.executeQuery();
                 
                 if(rs.next()){
                     MainAdmin m = new MainAdmin();
                     
                     this.hide();
                     m.setVisible(true);
                 }
                 
                 else{
                     JOptionPane.showMessageDialog(this, "Username or password incorrect!");
                     
                     txtUser.setText("");
                     txtPass.setText("");
                     txtUser.requestFocus();
                 }
                 }
                 
                 else if(utype == "User"){
                 pst = con.prepareStatement("select * from user where username = ? and password = ?");
                 
                 pst.setString(1, username);
                 pst.setString(2, password);
                 
                 rs = pst.executeQuery();
                 
                 if(rs.next()){
                     MainUser m = new MainUser();
                     
                     this.hide();
                     m.setVisible(true);
                 }
                 
                 else{
                     JOptionPane.showMessageDialog(this, "Username or password incorrect!");
                     
                     txtUser.setText("");
                     txtPass.setText("");
                     txtUser.requestFocus();
                 }
                 }
            }  
            
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex);
        }
      
    }                                        

    private void NewUserButtonActionPerformed(ActionEvent evt) {                                         
        
        NewUser nu = new NewUser();
        nu.setVisible(true);
    }                                        
                                 

    private void txtUserActionPerformed(ActionEvent evt) {
        txtPass.requestFocus();
    }                                       

    private void txtPassActionPerformed(ActionEvent evt) {                                        
        txtUtype.requestFocus();
    }                                                                               

    private void CancelButtonActionPerformed(ActionEvent evt) {
        System.exit(0);
    }                                        

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Login l = new Login();
                l.setVisible(true);
            }
        });
    }
                  
    private JButton NewUserButton;
    private JButton LoginButton;
    private JButton CancelButton;
    private JLabel Username;
    private JLabel Password;
    private JLabel Login;
    private JLabel UserType;
    private JPanel jPanel1;
    private JPanel jPanel2;
    private JPasswordField txtPass;
    private JTextField txtUser;
    private JComboBox<String> txtUtype;
                      
}
