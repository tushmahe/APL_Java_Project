package StudentManagement;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;
import javax.swing.table.*;


public class ListBatches extends JFrame {

    
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    PreparedStatement pst2;
    ResultSet rs;
    
    public ListBatches() {
        initComponents();
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/studentmanagement", "root", "");
            
            pst2 = con.prepareStatement("select * from batch");
            rs = pst2.executeQuery();
            
            Btable.removeAll();
            
            while(rs.next())
            {
                DefaultTableModel model = (DefaultTableModel) Btable.getModel();
                model.addRow(new Object[]{Integer.toString(rs.getInt(1)), rs.getString(2), Integer.toString(rs.getInt(3))});
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @SuppressWarnings("unchecked")
                        
    private void initComponents() {

        jScrollPane1 = new JScrollPane();
        Btable = new JTable();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        Btable.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Batch Name", "Year Admitted"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            @Override
            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Btable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(Btable);
        if (Btable.getColumnModel().getColumnCount() > 0) {
            Btable.getColumnModel().getColumn(0).setResizable(false);
            Btable.getColumnModel().getColumn(1).setResizable(false);
            Btable.getColumnModel().getColumn(2).setResizable(false);
        }

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 375, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 275, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }                        
    
    private JTable Btable;
    private JScrollPane jScrollPane1;
                    
}

